/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;
import javafx.beans.property.*;
/**
 *
 * @author Admin
 */
public class RecIntegral {
    private SimpleStringProperty bottom;//
 private SimpleStringProperty high;//
private SimpleStringProperty step;//

public RecIntegral(String bottom, String high, String step){
this.bottom = new SimpleStringProperty(bottom);
this.high = new SimpleStringProperty(high);
this.step = new SimpleStringProperty(step);
}


}
