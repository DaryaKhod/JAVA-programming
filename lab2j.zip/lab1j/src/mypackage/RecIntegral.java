
package mypackage;

/**
 *
 * @author Admin
 */
public class RecIntegral {
    public String bottom;
        public String high;
        public String step;
        
        public RecIntegral(String Bottom, String High, String Step)
        {
            this.bottom = Bottom;
            this.high = High;
            this.step = Step;
        }
 public String getBottom(){
        return bottom;
        }
        public String getHigh(){
        return high;
        }
        public String getStep(){
        return step;
        }

public void setBottom(String high){
this.high = high;
}
public void setHigh(String step){
this.step = step;
}

public void setStep(String step) {
this.step = step;
}
}
