package mypackage;

import java.io.Serializable;

public class RecIntegral implements Serializable {

    private static final long serialVersionUID = 1L;

    private double bottom;
    private double high;
    private double step;
    private double result;

    public RecIntegral(double bottom, double high, double step) {
        this.bottom = bottom;
        this.high = high;
        this.step = step;
        result = 0.0;
    }

    public RecIntegral() {

    }

    public RecIntegral(String bottom, String high, String step) throws RecIntegralException {
        if (!doubleTryParse(bottom)) {
            throw new RecIntegralException("ошибка в поле Нижняя");
        }
        this.bottom = Double.parseDouble(bottom);

        if (this.bottom < 0.000001 || this.bottom > 1000000) {
            throw new RecIntegralException("ошибка в поле Нижняя");
        }

        if (!doubleTryParse(high)) {
            throw new RecIntegralException("ошибка в поле Верхняя");
        }
        this.high = Double.parseDouble(high);

        if (this.high < 0.000001 || this.high > 1000000) {
            throw new RecIntegralException("ошибка в поле Верхняя");
        }

        if (!doubleTryParse(step)) {
            throw new RecIntegralException("ошибка в поле Шаг");
        }
        this.step = Double.parseDouble(step);

        if (this.step < 0.000001 || this.step > 1000000) {
            throw new RecIntegralException("ошибка в поле Шаг");
        }
        result = 0.0;
    }

    public boolean doubleTryParse(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NullPointerException | NumberFormatException exception) {
            return false;
        }
    }

    public double getBottom() {
        return bottom;
    }

    public double getHigh() {
        return high;
    }

    public double getStep() {
        return step;
    }

    public void setBottom(double bottom) {
        this.bottom = bottom;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    public void setStep(double step) {
        this.step = step;
    }

    public void setResult(double result) {
        this.result = result;
    }
}
