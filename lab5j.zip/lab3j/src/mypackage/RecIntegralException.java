    package mypackage;

    import javax.swing.JOptionPane;

    public class RecIntegralException extends Exception {
        public RecIntegralException(String message) {
            JOptionPane.showMessageDialog(null, message, "Exception", 0);
        }
    }
