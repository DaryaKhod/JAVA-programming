/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author Admin
 */
public class MyThread extends Thread {
   // private static final long serialVersionUID = 1L;
    private double bottom;
    private double high;
    private double step;
    private double result;

    public MyThread(double bottom, double high, double step) {
        this.bottom = bottom;
        this.high = high;
        this.step = step;
        result = 0.0;
        }
@Override
    public void run(){
        while (bottom < high) {
            double temp;
            temp = Math.cos(bottom) / 2;
            bottom += step;
            temp += Math.cos(bottom) / 2;
            result += temp * step;
            }

    }
    public synchronized double getResult(){
        return result;
    }
}


