package client;


import org.omg.IOP.TAG_JAVA_CODEBASE;
import server.MyThread;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;


public class Client {
    /* Порт сервера, к которому собирается
подключиться клиентский сокет */
    public final static int SERVICE_PORT = 50001;

    public static void main(String[] args) throws IOException {
        DatagramSocket clientSocket = new DatagramSocket();
        try{

            while (true) {
            /* Создайте экземпляр клиентского сокета.
            Нет необходимости в привязке к определенному порту */


                // Получите IP-адрес сервера
                InetAddress IPAddress = InetAddress.getByName("localhost");

                // Создайте соответствующие буферы
                byte[] sendingDataBuffer = new byte[1024];
                byte[] receivingDataBuffer = new byte[1024];

      /* Преобразуйте данные в байты
       и разместите в буферах */
                String sentence = "GET";
                sendingDataBuffer = sentence.getBytes();

                // Создайте UDP-пакет
                DatagramPacket sendingPacket = new DatagramPacket(sendingDataBuffer, sendingDataBuffer.length, IPAddress, SERVICE_PORT);

                // Отправьте UDP-пакет серверу
                clientSocket.send(sendingPacket);

                // Получите ответ от сервера, т.е. предложение из заглавных букв
                DatagramPacket receivingPacket = new DatagramPacket(receivingDataBuffer, receivingDataBuffer.length);
                clientSocket.receive(receivingPacket);

                // Выведите на экране полученные данные
                byte[] data = receivingPacket.getData();
                String receivedData = new String(data).trim();
                if (receivedData.equals("Нечего отправлять")) {
                    System.out.println("Нечего считать");
                    Thread.sleep(1000);
                    continue;
                }

                MyThread myThread = MyThread.convertToObj(receivedData);

                System.out.println("Отправляем на сервер: " + receivedData);
                MyThread result = execute(myThread);


                String sendingInfo = MyThread.convertToString(result);

                sendingDataBuffer = sendingInfo.getBytes(StandardCharsets.UTF_8);
                sendingPacket = new DatagramPacket(sendingDataBuffer, sendingDataBuffer.length, IPAddress, SERVICE_PORT);
                clientSocket.send(sendingPacket);
                Thread.sleep(1000);
            }

        }
        catch(Exception e) {
            e.printStackTrace();
            clientSocket.close();
        }
    }

    private static MyThread execute(MyThread myThread){
        double result = myThread.getResult();
        double bottom = myThread.getBottom();
        double high = myThread.getHigh();
        double step = myThread.getStep();

        while (bottom < high){
            double temp;
            temp = Math.cos(bottom)/2;
            bottom += step;
            temp += Math.cos(bottom)/2;
            result+= temp * step;
        }
        myThread.setResult(result);
        return myThread;
    }
}
