/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

/**
 *
 * @author Admin
 */
public class MyThread extends Thread {
   // private static final long serialVersionUID = 1L;
    private double bottom;
    private double high;
    private double step;
    private double result;
    private int i;

    public MyThread(double bottom, double high, double step, int i) {
        this.bottom = bottom;
        this.high = high;
        this.step = step;
        result = 0.0;
        this.i = i;
        }
@Override
    public void run(){
        while (bottom < high) {
            double temp;
            temp = Math.cos(bottom) / 2;
            bottom += step;
            temp += Math.cos(bottom) / 2;
            result += temp * step;
            }

    }
    public synchronized double getResult(){
        return result;
    }

    public double getBottom() {
        return bottom;
    }

    public double getHigh() {
        return high;
    }

    public double getStep() {
        return step;
    }

    public int getI() {
        return i;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public static MyThread convertToObj(String str){
         String[] split = str.split(" ");
        Double bottom = Double.valueOf(split[0]);
        Double high = Double.valueOf(split[1]);
        Double step = Double.valueOf(split[2]);
        Integer i = Integer.valueOf(split[4]);
        Double result = Double.valueOf(split[3]);
        MyThread myThread = new MyThread(bottom,high ,step , i);
        myThread.setResult(result);
        return myThread;
    }
    public static String convertToString(MyThread obj) {
        return obj.getBottom() + " " + obj.getHigh() + " " + obj.getStep() + " " + obj.getResult() + " " + obj.getI();
    }
}


