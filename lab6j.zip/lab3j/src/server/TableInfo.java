package server;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TableInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    List<RecIntegral> list = new ArrayList<>();

    public List<RecIntegral> getList() {
        return list;
    }

    public void setList(List<RecIntegral> list) {
        this.list = list;
    }
}