package server;



import javax.swing.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.LinkedList;
import java.util.Queue;

public class UDPServer extends Thread {

    Queue<MyThread> queueToSend;
    Queue<MyThread> queueToGet;
    public final static int SERVICE_PORT = 50001;
    private final JTable jTable1;

    public UDPServer(JTable jTable1) {
        this.jTable1 = jTable1;
        queueToGet = new LinkedList<>();
        queueToSend = new LinkedList<>();
    }

    @Override
    public void run() {
        super.run();
        // Создайте новый экземпляр DatagramSocket, чтобы получать ответы от клиента
        DatagramSocket serverSocket = null;

        byte[] sendingDataBuffer = new byte[1024];
        try {
            serverSocket = new DatagramSocket(SERVICE_PORT);

            System.out.println("Waiting for a client to connect...");
        } catch (SocketException e) {
            e.printStackTrace();
        }
        while (true) {
            DatagramPacket inputPacket = new DatagramPacket(new byte[1024], new byte[1024].length);
            try {
                serverSocket.receive(inputPacket);

                // Выведите на экран отправленные клиентом данные
                String receivedData = new String(inputPacket.getData()).trim();
                System.out.println("От клиента полученно: " + receivedData);
                if (receivedData.equals("GET")) {
                    MyThread poll = queueToSend.poll();
                    String sendingInfo = "";
                    System.out.println("Отправка данных клиенту");
                    if (poll == null) {
                        sendingInfo = "Нечего отправлять";
                    } else {
                        sendingInfo = MyThread.convertToString(poll);
                    }

                    sendingDataBuffer = sendingInfo.getBytes();

                    // Получите IP-адрес и порт клиента
                    InetAddress senderAddress = inputPacket.getAddress();
                    int senderPort = inputPacket.getPort();
                    DatagramPacket outputPacket = new DatagramPacket(
                            sendingDataBuffer, sendingDataBuffer.length,
                            senderAddress, senderPort
                    );

                    // Отправьте пакет клиенту
                    serverSocket.send(outputPacket);

                } else {
                    MyThread myThread = MyThread.convertToObj(receivedData);
                    jTable1.setValueAt(myThread.getResult(), myThread.getI(), 3);
                }
            } catch (SocketException ignored) {

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
